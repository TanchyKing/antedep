#' @importFrom stats dbinom dnbinom dpois optim qchisq qnorm uniroot
NULL
